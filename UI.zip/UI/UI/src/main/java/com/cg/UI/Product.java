package com.cg.UI;

import org.springframework.stereotype.Component;

@Component
public class Product {

	private int id;
	private String ProdName;
	private double price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProdName() {
		return ProdName;
	}

	public void setProdName(String prodName) {
		ProdName = prodName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", ProdName=" + ProdName + ", price=" + price + "]";
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String prodName, double price) {
		super();
		this.id = id;
		ProdName = prodName;
		this.price = price;
	}
}
