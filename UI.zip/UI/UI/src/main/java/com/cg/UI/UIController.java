package com.cg.UI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class UIController {
	@Autowired
	RestTemplate rest;
	
	
	
	@GetMapping("/prod/")
	public String prodDisplay(Model model) {
		System.out.println("suc1");
		Product prod[]=rest.getForObject("http://ProductClient/find/", Product[].class);
		System.out.println("suc2");
		model.addAttribute("prod", prod);
		return "DispProd";
	}
	
	@GetMapping("/prod/{id}")
	public String displayProdById(@PathVariable("id") int id, Model model) {
		Product prod=rest.getForObject("http://ProductClient/find/" + id, Product.class);
		model.addAttribute("prod",prod);
		return "Product1";
	}
	
	@RequestMapping("/addProductform/")
	public String addProdform(Model model) {
		return "addForm";
	}
	

	/*@RequestMapping("/addProduct/")
	public String addProd(@RequestBody Product prod,Model model) {
		rest.getForObject("http://ProductClient/find/", Product.class);
		return "addSuccess";
	}*/
	
	
}
